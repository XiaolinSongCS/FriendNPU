var eventInfo = document.getElementById("eventInfo");
var newEvent = document.getElementById("newEvent");

newEvent.onclick = function(){
   eventInfo.style.color = "blue";  
};

