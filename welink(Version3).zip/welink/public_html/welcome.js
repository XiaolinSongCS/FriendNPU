//slideshow
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
}
//----------------------------Sign Up Modal Box----------------------------
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn =  document.getElementById("footerBtn");
var btn1 = document.getElementById("signUpBtn");
var btn2 = document.getElementById("joinBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
};
btn1.onclick = function() {
    modal.style.display = "block";
};
btn2.onclick = function() {
    modal.style.display = "block";
};

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
};
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target === modal) {
        modal.style.display = "none";
    }
};

//-----------------------------------------log in Modal-----------------------------------
var modalOne= document.getElementById("myModalOne");
var btn3 = document.getElementById("logInBtn");
var spanOne=document.getElementById("closeOne");
btn3.onclick = function(){
    modalOne.style.display = "block";
};
spanOne.onclick = function() {
    modalOne.style.display = "none";
};