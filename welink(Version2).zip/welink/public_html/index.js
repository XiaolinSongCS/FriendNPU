//show more events
var btn = document.getElementById("showEvents");
btn.onclick = function(){
   btn.style.display = "none";
   document.getElementById("hiddenRow").style.display="block";
};

//instructions popover
$(document).ready(function(){
   $('[data-toggle="popover"]').popover(); 
});
